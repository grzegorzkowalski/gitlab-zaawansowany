import { increment, decrement, reset, incrementBy } from "./counter.js";

let value = 0;
const wynik = document.getElementById("wynik");

function render() {
  wynik.textContent = value;
}

document.getElementById("plus").addEventListener("click", () => { value = increment(value); render(); });
document.getElementById("plus10").addEventListener("click", () => { value = incrementBy(value, 10); render(); });
document.getElementById("minus").addEventListener("click", () => { value = decrement(value); render(); });
document.getElementById("reset").addEventListener("click", () => { value = reset(); render(); });
