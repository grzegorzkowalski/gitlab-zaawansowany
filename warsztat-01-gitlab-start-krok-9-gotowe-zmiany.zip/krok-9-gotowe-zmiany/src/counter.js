// Logika licznika — testowalna, bez zależności od przeglądarki.

export function increment(value) {
  return value + 1;
}

export function decrement(value) {
  // Licznik nie schodzi poniżej zera.
  return Math.max(0, value - 1);
}

export function reset() {
  return 0;
}

export function incrementBy(value, step) {
  return value + step;
}
