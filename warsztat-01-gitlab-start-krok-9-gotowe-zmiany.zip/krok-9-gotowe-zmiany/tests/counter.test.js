import { test } from "node:test";
import assert from "node:assert/strict";
import { increment, decrement, reset, incrementBy } from "../src/counter.js";

test("increment zwiększa wartość o 1", () => {
  assert.equal(increment(0), 1);
  assert.equal(increment(41), 42);
});

test("decrement zmniejsza wartość o 1", () => {
  assert.equal(decrement(5), 4);
});

test("decrement nie schodzi poniżej zera", () => {
  assert.equal(decrement(0), 0);
});

test("reset zwraca zero", () => {
  assert.equal(reset(), 0);
});

test("incrementBy zwiększa wartość o podany krok", () => {
  assert.equal(incrementBy(0, 10), 10);
  assert.equal(incrementBy(32, 10), 42);
});
