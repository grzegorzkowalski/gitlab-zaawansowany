import { increment, decrement, reset } from "./counter.js";

let value = 0;
const wynik = document.getElementById("wynik");

function render() {
  wynik.textContent = value;
}

document.getElementById("plus").addEventListener("click", () => { value = increment(value); render(); });
document.getElementById("minus").addEventListener("click", () => { value = decrement(value); render(); });
document.getElementById("reset").addEventListener("click", () => { value = reset(); render(); });
