# Paczka startowa — warsztat GitLab (licznik)

Zawartość rozpakuj do katalogu sklonowanego repozytorium, tak aby `package.json`
znalazł się w katalogu głównym repo.

Sprawdzenie lokalne (wymaga Node 18+):

    node --test tests/counter.test.js     # oczekiwane: pass 4 / fail 0

Dalsze kroki — patrz instrukcja warsztatu (Krok 5 i kolejne).
Plik `.gitlab-ci.yml` dodasz samodzielnie w Kroku 6.

Katalog `_dla-prowadzacego/` NIE trafia do repozytorium uczestnika:
- `gitlab-ci.gotowy.yml` — wzorcowy pipeline (rozwiązanie Kroku 6),
- `krok-9-gotowe-zmiany/` — pliki po modyfikacji "+10" (rozwiązanie Kroku 9).
